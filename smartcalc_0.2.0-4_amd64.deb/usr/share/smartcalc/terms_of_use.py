#!/usr/bin/python3

print(" _____                                __                   ")
print("|_   _|__ _ __ _ __ ___  ___    ___  / _|  _   _ ___  ___  ")
print("  | |/ _ \ '__| '_ ` _ \/ __|  / _ \| |_  | | | / __|/ _ \ ")
print("  | |  __/ |  | | | | | \__ \ | (_) |  _| | |_| \__ \  __/ ")
print("  |_|\___|_|  |_| |_| |_|___/  \___/|_|    \__,_|___/\___| ")
print("	")

print('1. I agree with GPL-3.0')
print("Bonus: If you want you can send me a idea or code of plugin for this programm")
print("This is all")
