#!/usr/bin/python3

print( "Choose function:")
print( "1. Basic operations	6.  Power and root")
print( "2. Square 		7.  ")
print( "3. Rectangle		8.  Sphere")
print( "4. Triangle		9.  Ohms law")
print( "5. Circle		10. Resistor")
print( "")
