#!/usr/bin/python3

from banner import sc

print(sc)
