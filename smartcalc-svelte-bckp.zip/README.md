# template-electron-svelte

Starter project with basic Svelte and Electron setup

## How to build

- `npm run dev` => Serve the svelte app over HTTP with live reload. Visit http://localhost:5000.
- `npm run electron` => Compiles the svelte app & opens it in Electron.
- `npm run electron-dev` => Compiles the svelte app & open it in Electron with live reload.
- `npm run dist-darwin` => Builds a OS X app. Open it with `open dist/mac/template-electron-svelte.app/`.
