<div unselectable="on" onselectstart="return false;" onmousedown="return false;">
    <slot />
</div>