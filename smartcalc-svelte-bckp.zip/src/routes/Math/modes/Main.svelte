<script>
    import {
        Container,
            Row,
            Col
    } from 'sveltestrap';
</script>

<Container>
    <Row>
        <Col>
            <h1>
                Welcome in math mode
            </h1>
            <p>
                Select from different modes as needed
            </p>
        </Col>
    </Row>
</Container>