<script>
    import {Input} from 'sveltestrap';
</script>

<Input label="Type your math problem" />